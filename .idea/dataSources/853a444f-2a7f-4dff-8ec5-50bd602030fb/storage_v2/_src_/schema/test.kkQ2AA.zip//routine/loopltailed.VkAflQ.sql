create
    definer = root@localhost function loopltailed() returns varchar(100)
begin
		declare i int default 10;
		declare x varchar(100);
		
		label: LOOP
		set i= i+1;
	  IF i=100 THEN
		LEAVE label; 
	  END IF; 
	  set @n_code=(select round(rand()*100,0)'rand varchar');
		set @n_total_price=(select round(rand()*100,0));
		set @n_time=(SELECT CONCAT('2018-11-' ,
				 LPAD(FLOOR(1 + RAND() * 30), 2, 0),-- 01-30
				 ' ',
         LPAD(FLOOR(RAND() * 24), 2, 0), -- 00-23
         ':',
         LPAD(FLOOR(RAND() * 60), 2, 0),-- 00-59
         ':',
         LPAD(FLOOR(RAND() * 60), 2, 0) -- 00-59
           ) 'rand time' );
	  insert into purchase(code,total_price,time)values(@n_code,@n_total_price,@n_time);
		END LOOP label;
		return x;
end;

