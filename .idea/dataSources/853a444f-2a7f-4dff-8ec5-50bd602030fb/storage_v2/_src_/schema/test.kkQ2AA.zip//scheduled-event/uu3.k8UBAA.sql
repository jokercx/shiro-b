create definer = root@localhost event uu3 on schedule
    every '2' SECOND
        starts '2020-06-23 11:03:37'
    on completion preserve
    disable
    do
    begin 
insert into cc(name) values('uyuy');
insert into xs(xsren) values('77yyy');
end;

