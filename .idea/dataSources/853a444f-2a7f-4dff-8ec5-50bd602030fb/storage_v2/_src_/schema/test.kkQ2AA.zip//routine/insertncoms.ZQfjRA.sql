create
    definer = root@localhost function insertncoms(n_price int) returns varchar(10)
begin
		insert into n_com(com_name,com_type)select d.name,d.type from detailed d where d.price>=n_price and d.type!='食品' and d.type!='饮品';
		return n_price;
end;

