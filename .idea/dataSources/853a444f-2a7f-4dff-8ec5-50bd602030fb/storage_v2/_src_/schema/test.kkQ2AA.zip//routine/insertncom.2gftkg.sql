create
    definer = root@localhost function insertncom(n_type varchar(10)) returns varchar(10)
begin
		insert into n_com(com_name,com_type) select d.name,d.type from detailed d,purchase p where d.id=p.id and d.type=n_type;
		return n_type;
end;

