create
    definer = root@localhost procedure gz(INOUT userName varchar(10), IN amount int, OUT msg varchar(50))
begin
		declare a_income int;
		set a_income=(select income from a_staff) ;
		if a_income> amount then
				set msg:=concat(userName,'高薪白领');
		elseif a_income =amount then 
				set msg:=concat(userName,'正常水平收入');
		end if;	
		
end;

