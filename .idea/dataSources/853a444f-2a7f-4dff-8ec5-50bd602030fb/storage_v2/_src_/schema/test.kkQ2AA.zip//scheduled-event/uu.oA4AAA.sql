create definer = root@localhost event uu on schedule
    every '2' SECOND
        starts '2020-06-23 10:59:29'
    on completion preserve
    enable
    do
    insert into cc(name) values('ppp');

