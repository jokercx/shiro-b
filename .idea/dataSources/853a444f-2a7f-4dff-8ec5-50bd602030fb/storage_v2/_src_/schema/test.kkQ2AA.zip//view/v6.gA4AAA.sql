create definer = root@localhost view v6 as
select `xs`.`xsren` AS `xsren`, date_format(`xs`.`xsdate`, '%Y-%m') AS `mm`, sum(`xs`.`xsnumber`) AS `num`
from `xs`
where (date_format(`xs`.`xsdate`, '%Y-%m') = '2020-02')
group by `xs`.`xsren`, `mm`;

