create definer = root@localhost trigger a
    before insert
    on class
    for each row
begin
		insert into student(id,name,sex,birth,department,address)values
		(907,'小红','女','1999','英语系','广东省深圳市');
end;

