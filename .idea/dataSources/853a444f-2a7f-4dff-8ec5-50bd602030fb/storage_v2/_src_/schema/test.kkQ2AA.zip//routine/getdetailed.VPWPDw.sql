create
    definer = root@localhost function getdetailed(n_name varchar(10)) returns varchar(10)
begin 
		declare n_type varchar(10);
		select type into n_type from detailed where name=n_name;
		return n_type;
end;

