create
    definer = root@localhost procedure gj()
begin 
		DECLARE lpindex int DEFAULT 0;
		DECLARE ym_v varchar(10);
		-- DECLARE x int DEFAULT 0;
		DECLARE c_ym cursor for select DATE_FORMAT(xsdate,'%Y-%m') as ym from xs group by  ym;
		-- DECLARE CONTINUE HANDLER FOR NOT FOUND SET x = 1; 
		
		select @count := count(*)  from (
	select  DATE_FORMAT(xsdate,'%Y-%m')  ym  from xs group by ym ) t;
		
		drop table if EXISTS bonus;
			create table bonus(
				id int not null PRIMARY key auto_increment,
				name varchar(10),
				number varchar(10),
				month varchar(10),
				type varchar(10),
				bonus int
			);
			
		open c_ym;
		mylo: loop
		  
		
			
			FETCH c_ym into ym_v;
			 
		select  @xsren_v := xsren , @xsmm_v := DATE_FORMAT(xsdate,'%Y-%m') as mm   , 
		 @xsnum_v := 	sum(xsnumber) as num   
     from xs   where DATE_FORMAT(xsdate,'%Y-%m')   = ym_v  
		  group by xsren , mm  order by num desc  limit 0,1;
		 
			if @xsnum_v >= 90 then
				set @jj = 1000;
			elseif @xsnum_v>=80 and @xsnum_v < 90 then
				set 	@jj = 500;
			else 
				set 	@jj = 20;
			end if;
		 
			
			insert into bonus(name,number,month,type,bonus) 
					values(@xsren_v, @xsnum_v,@xsmm_v,'月冠军',@jj);
			
				set lpindex  = lpindex + 1;  
				if lpindex = @count  then 
			    	leave mylo;  
			  end if ;
			
		end loop mylo;
		close c_ym;
		
		 -- 年冠军
		select  @xsren_v := xsren , @xsmm_v := DATE_FORMAT(xsdate,'%Y') as mm   , 
		 @xsnum_v := 	sum(xsnumber) as num   
     from xs  
		  group by xsren , mm  order by num desc  limit 0,1;
		
			insert into bonus(name,number,month,type,bonus) 
					values(@xsren_v, @xsnum_v,@xsmm_v,'年冠军',@jj);
	 
	end;

