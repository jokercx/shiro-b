create
    definer = root@localhost function insertDataToXs() returns varchar(100)
begin
		declare i int default 10;
		declare x varchar(100);
		 
		label: LOOP
		set i= i+1;
	  IF i=100 THEN
		LEAVE label; 
	  END IF; 
	  set @xsren_v=concat('张',(select round(rand()*100,0)));
		set @xsnumber_v=(select round(rand()*100,0));
		set @xsdate_v=( SELECT CONCAT('2020-',
		LPAD( FLOOR(1 + RAND() * 12), 2, 0)  ,'-' , LPAD(FLOOR(1 + RAND() * 30), 2, 0) ) );
					 
	  insert into xs(xsren,xsdate,xsnumber)values(@xsren_v,@xsdate_v,@xsnumber_v);
		END LOOP label;
		return x;
end;

