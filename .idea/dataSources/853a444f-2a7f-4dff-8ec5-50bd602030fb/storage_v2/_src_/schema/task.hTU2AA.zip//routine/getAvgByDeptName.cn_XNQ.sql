create
    definer = root@localhost function getAvgByDeptName(namev varchar(20)) returns double
BEGIN
	declare inc double;
	select avg(income) into inc from employ  where 
		dept_id  = (select id from dept where name = namev );
	select round(inc,2) into inc;
	return inc;
end;

