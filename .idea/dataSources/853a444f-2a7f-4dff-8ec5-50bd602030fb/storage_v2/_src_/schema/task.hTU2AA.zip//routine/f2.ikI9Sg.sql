create
    definer = root@localhost function f2(i int) returns varchar(10)
begin 
		declare str varchar(10);
		case  i
		when 1 THEN
			set str = '张三';
		when 2 then 
			set str = '张三1';
		else 
			set str = '张三2';
	end case; 
RETURN STR;
	end;

