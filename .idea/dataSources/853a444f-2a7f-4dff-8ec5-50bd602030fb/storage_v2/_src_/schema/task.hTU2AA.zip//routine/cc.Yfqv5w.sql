create
    definer = root@localhost procedure cc(IN pageNum int, IN pageSize int, OUT yy int)
begin
	 declare lstart int DEFAULT 0;
	 
	 set lstart = (pageNum-1)*pageSize;
	 
	 select *  from emp limit lstart,pageSize;	 
	 select * from emp;
	 set @xx = ( select f1() );
	 set yy = @xx;
	end;

