create
    definer = root@localhost procedure sff(IN str varchar(100), IN idv int)
begin
	
  set @excutSqlv = str;
	set @excutIdv = idv;
	set @excutName = '李四';
  PREPARE stmt FROM @excutSqlv;
	EXECUTE stmt using @excutIdv,@excutName;
  DEALLOCATE PREPARE stmt;
end;

