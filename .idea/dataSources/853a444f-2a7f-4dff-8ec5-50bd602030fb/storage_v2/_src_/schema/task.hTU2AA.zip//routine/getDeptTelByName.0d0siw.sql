create
    definer = root@localhost function getDeptTelByName(namev varchar(20)) returns varchar(20)
begin	
  declare tel_v varchar(20);
	select tel into tel_v from dept where name = namev;
	return tel_v;
end;

