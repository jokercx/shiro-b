create
    definer = root@localhost function getDeptTelById(id_v int) returns varchar(20)
begin	
	declare tel_v varchar(11);
	select tel into tel_v from dept where id = id_v;
	return tel_v;
end;

