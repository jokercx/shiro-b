create
    definer = root@localhost procedure deptcc(IN page_index int, IN page_size int, OUT total_count int,
                                              OUT total_page int)
begin
		DECLARE begin_no INT;
		SET begin_no = (page_index-1)*page_size;
 
		-- 分页查询列表
		SELECT * FROM dept
		WHERE id >= (
			SELECT id FROM dept
			ORDER BY id ASC
			LIMIT begin_no,1
		)
		ORDER BY id ASC
		LIMIT page_size;
 
		-- 计算数据总数
		SELECT COUNT(1) INTO total_count FROM dept;
 
		-- 计算总页数
		SET total_page = FLOOR((total_count + page_size - 1) / page_size);
end;

