create
    definer = root@localhost function getName() returns varchar(10)
begin  -- { 
 return '张三三';
end;

